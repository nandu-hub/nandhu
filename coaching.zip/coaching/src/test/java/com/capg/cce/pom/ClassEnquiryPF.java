package com.capg.cce.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
/*
 * PageFactory Class for Enquiry Page
 */
public class ClassEnquiryPF {
	WebDriver driver;

	@FindBy(name = "fname")
	@CacheLookup
	WebElement firstName;

	@FindBy(xpath = "//*[@name='lname']")
	@CacheLookup
	WebElement lastName;

	@FindBy(how = How.ID, using = "emails")
	@CacheLookup
	WebElement email;

	@FindBy(name = "mobile")
	@CacheLookup
	WebElement mobile;

	@FindBy(name = "D6")
	@CacheLookup
	WebElement tution;

	@FindBy(name = "D5")
	@CacheLookup
	WebElement city;

	@FindBy(name = "D4")
	@CacheLookup
	WebElement mode;

	@FindBy(how = How.ID, using = "Submit1")
	@CacheLookup
	WebElement submitButton;

	@FindBy(how = How.ID, using = "enqdetails")
	@CacheLookup
	WebElement enquiry;

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}

	public WebElement getTution() {
		return tution;
	}

	public void setTution(String tution) {
		Select selectTution = new Select(this.tution);
		selectTution.selectByVisibleText(tution);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		Select selectCity = new Select(this.city);
		selectCity.selectByVisibleText(city);
	}

	public WebElement getMode() {
		return mode;
	}

	public void setMode(String mode) {
		Select selectMode = new Select(this.mode);
		selectMode.selectByVisibleText(mode);
	}

	public WebElement getSubmitButton() {
		return submitButton;
	}

	public void setSubmitButton() {
		this.submitButton.click();
	}

	public WebElement getEnquiry() {
		return enquiry;
	}

	public void setEnquiry(String enquiry) {
		this.enquiry.sendKeys(enquiry);
	}

	// initiating Elements
	public ClassEnquiryPF(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

}
