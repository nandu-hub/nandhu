package com.capg.cce;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = {
		"pretty" }, features = "C:\\Users\\pnandu\\Desktop\\exam mod4\\coaching\\src\\test\\resources\\coachingClassEnquiry\\coachingClassEnquiry.feature", glue = "com.capg.cce")
public class TestRunner {

}