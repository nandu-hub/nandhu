package com.pages1;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.base1.TestBase1;
//import com.pages.ResultPage;

public class ResultPage1 extends TestBase1 {

	
	public ResultPage1() throws IOException {
		super();
		PageFactory.initElements(driver,this);
		// TODO Auto-generated constructor stub
	}
	
	@FindBy(xpath="//*[@id=\"FirstName\"]")
	WebElement fbox;
	
	public String validateTitle()
	{
		return driver.getTitle();
	}
	
	/*public String validatef(String fname) throws IOException
	{
		fbox.sendKeys(fname);
		return fname;
	}
*/
	
	public void setFirstname(String firstname){

	   fbox.sendKeys(firstname);
	   //System.out.println(firstname);
	  // return firstname;
	   
	 
	}

}
