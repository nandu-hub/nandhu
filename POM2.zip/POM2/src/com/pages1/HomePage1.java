package com.pages1;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.base1.TestBase1;

public class HomePage1 extends TestBase1{

	public HomePage1() throws IOException {
		
		super();
		PageFactory.initElements(driver, this);//creates page object
		// TODO Auto-generated constructor stub
	}
	
	/*@FindBy(name="q")
	WebElement searchBox;*/
	
	@FindBy(xpath="/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")
	WebElement searchBtn;
	
	public String validateTitle() {
		System.out.println("ch"+driver.getTitle());
		return driver.getTitle();
		
	}
	
	public ResultPage1 launch() throws IOException {
		/*searchBox.sendKeys(txt);*/
		
		searchBtn.click();
		
		return new ResultPage1();
	}
	

}
