package com.testscripts1;

import java.io.IOException;

import org.testng.Assert;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
//import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.base1.TestBase1;

import com.pages1.HomePage1;
import com.pages1.ResultPage1;

public class ResultPageTest1 extends TestBase1 {

	HomePage1 homePage;
    ResultPage1 resultPage;
	public ResultPageTest1() throws IOException {
		super();
		
		// TODO Auto-generated constructor stub
	}
	
	@Test(priority=1)
	 public void validateTitleTest() {
		 String pageTitle =resultPage.validateTitle();
		 System.out.println("ch111"+driver.getTitle());
		 AssertJUnit.assertEquals(pageTitle, "Demo Web Shop. Register");
	 }
	
	@Test(priority=2)
	 public void validateFnameTest() {
		
		
	    String firstname1 =prop.getProperty("firstname");
	    System.out.println(firstname1);
	    Assert.assertEquals(firstname1, "Nandu");
		
	 }
	
	
	 /* @BeforeMethod
	  public void beforeMethod1() throws Throwable {
	      
	     initiliazation();
	   //  homePage=new HomePage1();
	     String firstname = prop.getProperty("firstname");
	     resultPage = homePage.launch();
	     resultPage.setFirstname(firstname);
	  }*/
	
	/*@Test(priority=2)
	 public void validatefTest() {
		 String pageTitle =resultPage.validatef();
		 System.out.println("ch11"+driver.getTitle());
		 AssertJUnit.assertEquals(pageTitle, "Demo Web Shop. Register");
	 }*/
	
	@BeforeTest
	 public void beforeMethod() throws Throwable {
	      
	     initiliazation();
	     homePage=new HomePage1();
	     resultPage = new ResultPage1();
	     resultPage = homePage.launch();
	     String firstname = prop.getProperty("firstname");
	   resultPage.setFirstname(firstname);
	    
	  }
	  
    @AfterTest
    public void afterMethod() throws Throwable
    {
    	
    }
}
