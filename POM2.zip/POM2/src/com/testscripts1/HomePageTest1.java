package com.testscripts1;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.base1.TestBase1;
import com.pages1.HomePage1;

public class HomePageTest1 extends TestBase1 {

	HomePage1 homePage;
	public HomePageTest1() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

	@Test(priority=1)
	public void validateTitleTest()
	{
		String homePageTitle  = homePage.validateTitle();
		 System.out.println("Page Title :" + homePageTitle);
		 
		 Assert.assertEquals(homePageTitle, "Demo Web Shop");
	}
	/*@Test(priority=2)
	public void launchTest() throws IOException {
		String txt = prop.getProperty("txt");
		homePage.launch(txt);
		 System.out.println("Page Title :" + txt);
		 Assert.assertEquals(txt, "Phone");
	}
*/
	@BeforeMethod
	public void setup() throws IOException
	{
		initiliazation();
		homePage= new HomePage1();
	}
	@AfterMethod
	public void setout() throws IOException
	{
		//driver.quit();
	}
}
